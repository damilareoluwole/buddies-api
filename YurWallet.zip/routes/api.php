<?php

use App\Http\Controllers\BankController;
use App\Http\Controllers\ForgotPasswordController;
use App\Http\Controllers\JWTAuthController;
use App\Http\Controllers\ProfileController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::prefix('auth')->group(function () {
    Route::prefix('register')->group(function () {
        Route::post('/', [JWTAuthController::class, 'register'])->name('jwt-auth.register');
        Route::post('/activate', [JWTAuthController::class, 'activate'])->name('register.activate');
        Route::post('/complete', [JWTAuthController::class, 'createPinAndAvatar'])->name('register.complete');
        Route::post('/otp/resend', [JWTAuthController::class, 'resendOtp'])->name('otp.resend');
    });
    
    Route::post('/login', [JWTAuthController::class, 'login'])->name('jwt-auth.login');
    
    Route::prefix('reset-password')->group(function () {
        Route::post('/phone', [ForgotPasswordController::class, 'passwordForgotPhone'])->name('reset-password.phone');
        Route::post('/otp', [ForgotPasswordController::class, 'validateOtp'])->name('reset-password.otp');
        Route::post('/complete', [ForgotPasswordController::class, 'changePassword'])->name('reset-password.password');
    });
});

Route::middleware('auth')->group(function () {
    Route::prefix('profile')->group(function () {
        Route::get('/', [ProfileController::class, 'index'])->name('user.profile');
    });

    Route::prefix('bank')->group(function () {
        Route::get('/', [BankController::class, 'getBanks'])->name('bank.banks');
        Route::post('/account/verify', [BankController::class, 'nameEnquiry'])->name('bank.nameEnquiry');
    });
});