<?php

return [
    'url' => env('PULSE', 'http://pulse.parkwayprojects.xyz/api/pulse/createpulse')
];
