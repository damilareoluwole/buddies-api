<?php

namespace App\Services;

use App\Models\Bank;
use Exception;
use DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;

class BankService
{
    public function getBanks()
    {
        return Bank::all();
    }

    public function nameEnquiry($accountNumber, $bankCode)
    {
        try{
            $response = Http::withToken(config('readycash.token'))->post(config('readycash.agent_url') . '/agent/transact/nameenquiry', [
                "accountNumber" => "8441030191", #$accountNumber,
                "bankCode" => "311", #$bankCode
            ]);

            if (!$response->ok())
                return['status' => false, 'data' => []];
            
            $response = $response->json(); 

            if (!isset($response['code']) || $response['code'] != '00' || !isset($response['desc']))
                return['status' => false, 'data' => []];
            
            return [
                'status' => true,
                'data' => [
                    'accountNumber' => $accountNumber,
                    'bankCode' => $bankCode,
                    'accountName' => $response['desc'],
                    'bvn' => $response['bvn'] ?? null
                ]
            ];
        } catch (Exception $e) {
            Log::channel('name_enquiry_error')->info($e);
            return response()->json([
                'status' => false, 
                'data' => []
            ]);
        }
    }

    public function bankTransfer($accountNumber, $bankCode, $amount, $narration)
    {
        // $response = Http::withToken(config('readycash.token'))->post(config('readycash.wallet_url') . '/create', [
        //     "firstName" => $request->firstName,
        //     "lastName" => $request->lastName,
        //     "phone" => $request->phone,
        //     "email" => $request->email,
        //     "account" => [
        //         "alias" => $request->firstName.' '.$request->lastName,
        //         "currencyCode" => 'NGN'
        //     ]
        // ]);

        // if (!$response->ok() || !isset($response->json()['accountNumber'])) {
        //     return response()->json(['status' => false, 'message' => 'Unable to complete this request.', 'data' => []], Response::HTTP_BAD_REQUEST);
        // }
        
        return [];
    }
}