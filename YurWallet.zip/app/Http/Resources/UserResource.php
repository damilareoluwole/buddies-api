<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'username' => $this->username,
            'firstName' => $this->firstName,
            'lastName' => $this->lastName,
            'phone' => $this->phone,
            'email' => $this->email,
            'avatar' => ($this->avatar) ? env('APP_URL').Storage::url($this->avatar) : env('APP_URL').'/storage/images/users/default.jpg',
            'tier' => $this->tier,
            'gender' => $this->gender,
            'dateOfBirth' => $this->dateOfBirth,
            'bvn' => $this->bvn,
            'address' => $this->address,
            'addressState' => $this->addressState,
            'addressCity' => $this->addressCity,
            'onboardingStage' => $this->onboardingStage,
            'otpStage' => $this->otpStage,
            'pinStage' => $this->pinStage,
            'wallet' => WalletResource::make($this->wallet)
        ];
    }
}