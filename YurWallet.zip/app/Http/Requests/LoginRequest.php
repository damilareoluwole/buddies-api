<?php

namespace App\Http\Requests;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;

class LoginRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'phone' => [
                'required', 
                'min:11',
                'exists:users,phone'
            ],
            'password' => ['required']
        ];
    }
}

// function ($attribute, $value, $fail) {
//     $user = User::where('phone', $value)->first();
//     if (!$user) {
//         $fail('The ' . $attribute . ' belongs to no registered user.');
//     }else{
//         if(!$user->email_verified_at || !$user->email_verified_at){
//             $fail('The user with this phone ' . $attribute . ' has not been activated.');
//         }
//     }
// }