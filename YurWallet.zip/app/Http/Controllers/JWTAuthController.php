<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Http\Requests\PinAndAvartarRequest;
use App\Http\Requests\RegisterRequest;
use App\Http\Requests\ResendOtpRequest;
use App\Http\Requests\ValidateOtpRequest;
use App\Http\Resources\UserResource;
use App\Models\User;
use App\Models\Wallet;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;

class JWTAuthController extends Controller
{
    public function register(RegisterRequest $request)
    {
        DB::beginTransaction();

        try {
            $user = User::updateOrCreate(
                [
                    'phone' => $request->phone,
                    'email' => $request->email,
                ],
                [
                    'username' => $this->createUsername($request->firstName, $request->lastName),
                    'firstName' => $request->firstName,
                    'lastName' => $request->lastName,
                    'phone' => $request->phone,
                    'email' => $request->email,
                    'onboardingStage' => 1,
                    'password' => Hash::make($request->password)
                ]
            );

            $response = Http::withToken(config('readycash.token'))->post(config('readycash.wallet_url') . '/create', [
                "firstName" => $request->firstName,
                "lastName" => $request->lastName,
                "phone" => $request->phone,
                "email" => $request->email,
                "account" => [
                    "alias" => $request->firstName.' '.$request->lastName,
                    "currencyCode" => 'NGN'
                ]
            ]);
            
            Log::channel('account_creation_error')->info($response->json());
            
            if (!$response->ok() || !isset($response->json()['accountNumber'])) {
                return response()->json([
                    'status' => false, 
                    'message' => 'Unable to complete this request. Please try again', 
                    'data' => []
                ], Response::HTTP_BAD_REQUEST);
            }

            Wallet::updateOrCreate(
                [
                    "user_id" => $user->id
                ],
                [
                    "user_id" => $user->id,
                    "accountNumber" => $response->json()['accountNumber']
                ]
            );

            DB::commit();

            return response()->json([
                'status' => true, 
                'message' => 'Enter the OTP sent to your phone.', 
                'data' => ['user' => UserResource::make($user)]
                ]);
                
        } catch (Exception $e) {
            DB::rollBack();
            Log::channel('account_creation_error')->info($e);
            return response()->json(['status' => false, 'message' => 'Unable to complete this request.', 'data' => []], Response::HTTP_BAD_REQUEST);
        }
    }

    public function resendOtp(ResendOtpRequest $request)
    {
        try {
            $user = User::find($request->userId);
            $wallet = $user->wallet;
             
            $response = Http::withToken(config('readycash.token'))->post(config('readycash.wallet_url') . "/$wallet->accountNumber".'/otp');

            if (!$response->ok()) {
                return response()->json(['status' => false, 'message' => 'Unable to resend OTP.', 'data' => []], Response::HTTP_BAD_REQUEST);
            }

            return response()->json(['status' => true, 'message' => 'OTP sent successfully.', 'data' => ['user' => UserResource::make($user)]]);
        } catch(Exception $e) {
            Log::channel('account_creation_error')->info($e);
            return response()->json(['status' => false, 'message' => 'Unable to complete this request.'], Response::HTTP_BAD_REQUEST);
        }
    }

    public function activate(Request $request)
    {
        try {
            $user = User::find($request->userId);
            $response = Http::withToken(config('readycash.token'))->post(config('readycash.wallet_url') . '/activate', [
                "accountNumber" => "8441030775",//$user->accountNumber,
                "otp" => $request->otp
            ]);

            if (!$response->ok()) {
                return response()->json(['status' => false, 'message' => 'Unable to complete this request.', 'data' => []], Response::HTTP_BAD_REQUEST);
            }

            $user->phone_verified_at = now();
            $user->email_verified_at = now();
            $user->otpStage = 1;
            $user->save();

            return response()->json(['status' => true, 'message' => 'Account activated successfully.', 'data' => ['user' => UserResource::make($user)]]);
        } catch(Exception $e) {
            Log::channel('account_creation_error')->info($e);
            return response()->json(['status' => false, 'message' => 'Unable to complete this request.'], Response::HTTP_BAD_REQUEST);
        }
    }

    public function createPinAndAvatar(PinAndAvartarRequest $request)
    {
        $user = User::find($request->userId);
        $user->pin = Hash::make($request->pin);
        $user->avatar = $request->file('avatar')->store('public/images/users');
        $user->pinStage = 1;
        $user->save();

        $token = auth()->login($user);
        return $this->doLogin($token);
    }

    protected function createUsername($firstName, $lastName)
    {
        $username = strtolower($firstName.$lastName);
        $user = User::where('username', 'LIKE', "%$username%")->get();
        if(count($user) > 0)
            $username = $username.count($user); 

        return $username;
    }

    public function login(LoginRequest $request)
    {
        $data = $request->validated();
        $user = User::byPhone($data['phone'])->first();
        if(! $user->pinStage)
            return response()->json([
                    'status' => false, 
                    'message' => 'User registration is incomplete.', 
                    'data' => [
                        'user' => UserResource::make($user)
                    ]
                ],
                Response::HTTP_BAD_REQUEST
            );
        
        $token = auth()->attempt($data);
        return $this->doLogin($token);
    }

    private function doLogin($token)
    {
        if (!$token) {
            return response()->json([
                    'status' => false, 
                    'message' => 'Unable to complete login request. Check your credentials and try again.', 
                    'data' => []
                ],
                Response::HTTP_UNAUTHORIZED
            );
        }

        return response()->json([
            'status' => true,
            'message' => 'Login was Successful',
            'data' => [
                'user' => UserResource::make(auth()->user()),
                'authorization' => [
                    'token' => $token,
                    'type' => 'Bearer'
                ]
            ]
        ]);
    }

    public function logout()
    {
        auth()->logout();

        return response()->json([
            'message' => 'User has been logged out'
        ]);
    }

    public function refresh()
    {
        return response()->json([
            'user' => auth()->user(),
            'authorisation' => [
                'token' => auth()->refresh(),
                'type' => 'bearer',
            ]
        ]);
    }
}