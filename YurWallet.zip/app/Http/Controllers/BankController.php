<?php

namespace App\Http\Controllers;

use App\Http\Requests\NameEnquiryRequest;
use Illuminate\Http\Request;
use App\Services\BankService;

class BankController extends Controller
{
    private $bankService;

    public function __construct(BankService $bankService)
    {
        $this->bankService = $bankService;
    }

    public function getBanks()
    {
        $banks = $this->bankService->getBanks();

        return response()->json([
            'status' => true, 
            'message' => 'Records found', 
            'data' => [
                'banks' => $banks
                ]
            ]);
    }

    public function nameEnquiry(NameEnquiryRequest $request)
    {
        $data = $request->validated();
        $details = $this->bankService->nameEnquiry($data['accountNumber'], $data['bankCode']);
        
        if(! $details['status'])
            return response()->json([
                'status' => false, 
                'message' => 'Unable to comple name enquiry', 
                'data' => []
            ]);
        
        return response()->json([
            'status' => true, 
            'message' => 'Record found', 
            'data' => [
                'accountDetails' => $details['data']
            ]
        ]);
    }

    public function bankTransfer(Request $request)
    {
        $data = $request->validate([
            'amount' => 'required|numeric',
            'accountNumber' => 'required|string|digits:10',
            'accountName' => 'required|string',
            'bankCode' => 'required|string|max:3',
            'narration' => 'required|string'
        ]);

        //Check wallet balance
        
        //Check account tier

        //Record in bank transfer
        
        $transfer = $this->bankService->bankTransfer(
            $data['accountNumber'],
            $data['bankCode'],
            $data['amount'],
            $data['narration']
        );

        return response()->json(['status' => true, 'message' => 'Transaction Successful', 'data' => ['accountDetails' => $transfer]]);
    }
}