<?php

namespace App\Http\Controllers;

use App\Http\Requests\ChangePasswordRequest;
use App\Http\Requests\ForgotPasswordPhoneRequest;
use App\Http\Requests\ResetPasswordValidateOtpRequest;
use App\Jobs\SmsJob;
use App\Models\User;
use App\Services\SMS;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Response;

class ForgotPasswordController extends Controller
{
    public function passwordForgotPhone(ForgotPasswordPhoneRequest $request)
    {
        $user = $this->checkUser($request->validated()['phone']);
            
        if(! $user)
            return $this->InvalidUserResponse('No user found for this phone.');

        $code = (new SMS)->generateCode();
        $user->otp = $code;
        $user->save();
        
        SmsJob::dispatch([$user], "To complete your password reset, enter the OTP $code");
        
        return response()->json([
            'status' => true, 
            'message' => 'OTP sent.', 
            'data' => [
                'phone' => $user->phone
            ]
        ]);
    }

    public function validateOtp(ResetPasswordValidateOtpRequest $request)
    {
        $user = $this->checkUser($request->validated()['phone']);
            
        if(! $user)
            return $this->InvalidUserResponse('No user found for this phone.');

        if($request->validated()['otp'] != $user->otp)
            return $this->InvalidUserResponse('Invalid OTP.');

        $user->otp = null;
        $user->save();

        return response()->json([
            'status' => true, 
            'message' => 'OTP confirmed successfully.', 
            'data' => [
                'phone' => $user->phone
            ]
        ]);
    }

    public function changePassword(ChangePasswordRequest $request)
    {
        $user = $this->checkUser($request->validated()['phone']);
            
        if(! $user)
            return $this->InvalidUserResponse('No user found for this phone.');
            
        if (! Hash::check($request->validated()['pin'], $user->pin)) 
            return $this->InvalidUserResponse('Invalid Pin.');

        $user->password = Hash::make($request->validated()['password']);
        $user->save();

        return response()->json([
                'status' => true, 
                'message' => 'Password reset successfully.', 
                'data' => [
                    'phone' => $user->phone
                ]
            ]);
    }

    protected function checkUser($phone){
        $user = User::byPhone($phone)
            ->whereNotNull('phone_verified_at')
            ->whereNotNull('email_verified_at')
            ->first();
            
        if(! $user)
            return [];
        
        return $user;
    }

    protected function InvalidUserResponse($message)
    {
        return response()->json([
                'status' => false, 
                'message' => $message, 
                'data' => []
            ], Response::HTTP_UNAUTHORIZED);
    }
}