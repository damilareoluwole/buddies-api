<?php

namespace App\Jobs;

use App\Services\SMS;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SmsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $users;
    protected $message;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($users, $message)
    {
        $this->users = $users; 
        $this->message = $message;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $sms = new SMS();
        $sms->users($this->users);
        $sms->message($this->message);
        $sms->sendSMS();
    }
    
}