<?php

namespace Database\Seeders;

use App\Models\Tier;
use Illuminate\Database\Seeder;

class TierSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tiers = [
            [
                "dailyTransactionLimit"=> 50000,
                "maxAccountBalance"=> 300000,
                "name"=> "Tier 1"
            ],
            [
                "dailyTransactionLimit"=> 200000,
                "maxAccountBalance"=> 500000,
                "name"=> "Tier 2",
            ],
            [
                "dailyTransactionLimit"=> 5000000,
                "maxAccountBalance"=> "Unlimited",
                "name"=> "Tier 3",
            ]
        ];

        foreach ($tiers as $tier) {
            if (Tier::where('name', $tier['name'])->exists()) {
                continue;
            }

            Tier::create($tier);
        }
    }
}