<?php

namespace Database\Seeders;

use App\Models\Bank;
use Illuminate\Database\Seeder;

class BanksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $banks = [
            [
                "cbnBankCode"=> "090133",
                "code"=> "090133",
                "name"=> " AL-Barakah Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090197",
                "code"=> "090197",
                "name"=> "ABU Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "044",
                "code"=> "000014",
                "name"=> "Access Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "315",
                "code"=> "100013",
                "name"=> "AccessMobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090134",
                "code"=> "090134",
                "name"=> "Accion Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090160",
                "code"=> "090160",
                "name"=> "Addosser Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090131",
                "code"=> "090131",
                "name"=> "Allworkers Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090169",
                "code"=> "090169",
                "name"=> "Alpha Kapital Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090180",
                "code"=> "090180",
                "name"=> "Amju Unique Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090116",
                "code"=> "090116",
                "name"=> "AMML MFB",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090143",
                "code"=> "090143",
                "name"=> "Apeks Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090188",
                "code"=> "090188",
                "name"=> "Baines Credit Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090136",
                "code"=> "090136",
                "name"=> "Baobab Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090127",
                "code"=> "090127",
                "name"=> "BC Kash Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090117",
                "code"=> "090117",
                "name"=> "Boctrust Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090148",
                "code"=> "090148",
                "name"=> "Bowen Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "316",
                "code"=> "100005",
                "name"=> "Cellulant",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090154",
                "code"=> "090154",
                "name"=> "CEMCS Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "317",
                "code"=> "100015",
                "name"=> "ChamsMobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090141",
                "code"=> "090141",
                "name"=> "Chikum Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090144",
                "code"=> "090144",
                "name"=> "CIT Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "023",
                "code"=> "000009",
                "name"=> "Citi Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090130",
                "code"=> "090130",
                "name"=> "Consumer Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "070006",
                "code"=> "070006",
                "name"=> "Covenant MFB",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090159",
                "code"=> "090159",
                "name"=> "Credit Afrique Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090167",
                "code"=> "090167",
                "name"=> "Daylight Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "063",
                "code"=> "000005",
                "name"=> "Diamond Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090156",
                "code"=> "090156",
                "name"=> "e-Barcs Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "318",
                "code"=> "100021",
                "name"=> "Eartholeum",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "050",
                "code"=> "000010",
                "name"=> "Ecobank Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "307",
                "code"=> "100008",
                "name"=> "EcoMobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090097",
                "code"=> "090097",
                "name"=> "Ekondo MFB",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090114",
                "code"=> "090114",
                "name"=> "Empire trust MFB",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "",
                "code"=> "000019",
                "name"=> "Enterprise Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090189",
                "code"=> "090189",
                "name"=> "Esan Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090166",
                "code"=> "090166",
                "name"=> "Eso-E Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "306",
                "code"=> "100006",
                "name"=> "eTranzact",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090179",
                "code"=> "090179",
                "name"=> "FAST Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "319",
                "code"=> "100014",
                "name"=> "FBNMobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "214",
                "code"=> "000003",
                "name"=> "FCMB",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "320",
                "code"=> "100001",
                "name"=> "FET",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090153",
                "code"=> "090153",
                "name"=> "FFS Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "070",
                "code"=> "000007",
                "name"=> "Fidelity Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "321",
                "code"=> "100019",
                "name"=> "Fidelity Mobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090126",
                "code"=> "090126",
                "name"=> "Fidfund Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090111",
                "code"=> "090111",
                "name"=> "FinaTrust Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "011",
                "code"=> "000016",
                "name"=> "First Bank of Nigeria",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090164",
                "code"=> "090164",
                "name"=> "First Royal Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "070002",
                "code"=> "070002",
                "name"=> "Fortis Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "322",
                "code"=> "100016",
                "name"=> "FortisMobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "323",
                "code"=> "400001",
                "name"=> "FSDH",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090145",
                "code"=> "090145",
                "name"=> "Fullrange Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090158",
                "code"=> "090158",
                "name"=> "Futo Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090168",
                "code"=> "090168",
                "name"=> "Gashua Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090122",
                "code"=> "090122",
                "name"=> "Gowans Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090178",
                "code"=> "090178",
                "name"=> "GreenBank Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090195",
                "code"=> "090195",
                "name"=> "Grooming Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "058",
                "code"=> "999998",
                "name"=> "GTBankPlc",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "324",
                "code"=> "100009",
                "name"=> "GTMobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090147",
                "code"=> "090147",
                "name"=> "Hackman Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090121",
                "code"=> "090121",
                "name"=> "Hasal Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "325",
                "code"=> "100017",
                "name"=> "Hedonmark",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "084",
                "code"=> "000020",
                "name"=> "Heritage",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090175",
                "code"=> "090175",
                "name"=> "HighStreet Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090118",
                "code"=> "090118",
                "name"=> "IBILE Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090157",
                "code"=> "090157",
                "name"=> "Infinity Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090149",
                "code"=> "090149",
                "name"=> "IRL Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "301",
                "code"=> "000006",
                "name"=> "JAIZ Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090191",
                "code"=> "090191",
                "name"=> "KCMB Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "082",
                "code"=> "000002",
                "name"=> "Keystone Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090267",
                "code"=> "090267",
                "name"=> "KUDA BANK",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090155",
                "code"=> "090155",
                "name"=> "La  Fayette Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090177",
                "code"=> "090177",
                "name"=> "Lapo Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090171",
                "code"=> "090171",
                "name"=> "Mainstreet Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090174",
                "code"=> "090174",
                "name"=> "Malachy Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090192",
                "code"=> "090192",
                "name"=> "Midland Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "313",
                "code"=> "100011",
                "name"=> "Mkudi",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090129",
                "code"=> "090129",
                "name"=> "Money Trust Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "326",
                "code"=> "100020",
                "name"=> "MoneyBox",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090190",
                "code"=> "090190",
                "name"=> "Mutual Benefits Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090151",
                "code"=> "090151",
                "name"=> "Mutual Trust Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090152",
                "code"=> "090152",
                "name"=> "Nagarta Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090128",
                "code"=> "090128",
                "name"=> "Ndiorah Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090194",
                "code"=> "090194",
                "name"=> "NIRSAL Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "070001",
                "code"=> "070001",
                "name"=> "NPF MicroFinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090119",
                "code"=> "090119",
                "name"=> "Ohafia Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090161",
                "code"=> "090161",
                "name"=> "Okpoga Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "301",
                "code"=> "100002",
                "name"=> "Pagatech",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "070008",
                "code"=> "070008",
                "name"=> "Page Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090004",
                "code"=> "090004",
                "name"=> "Parralex Microfinance bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "305",
                "code"=> "100004",
                "name"=> "Paycom",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090137",
                "code"=> "090137",
                "name"=> "PecanTrust Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090196",
                "code"=> "090196",
                "name"=> "Pennywise Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090135",
                "code"=> "090135",
                "name"=> "Personal Trust Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090165",
                "code"=> "090165",
                "name"=> "Petra Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090125",
                "code"=> "090125",
                "name"=> "Regent Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090173",
                "code"=> "090173",
                "name"=> "Reliance Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090198",
                "code"=> "090198",
                "name"=> "RenMoney Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090132",
                "code"=> "090132",
                "name"=> "Richway Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090138",
                "code"=> "090138",
                "name"=> "Royal Exchange Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090140",
                "code"=> "090140",
                "name"=> "Sagamu Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090112",
                "code"=> "090112",
                "name"=> "Seed Capital Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "076",
                "code"=> "000008",
                "name"=> "Skye Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "221",
                "code"=> "000012",
                "name"=> "StanbicIBTC Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "304",
                "code"=> "100007",
                "name"=> "StanbicMobileMoney",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "068",
                "code"=> "000021",
                "name"=> "StandardChartered",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090162",
                "code"=> "090162",
                "name"=> "Stanford Microfinance Bak",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "232",
                "code"=> "000001",
                "name"=> "Sterling Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "327",
                "code"=> "100022",
                "name"=> "Sterling Mobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090115",
                "code"=> "090115",
                "name"=> "TCF MFB",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "328",
                "code"=> "100010",
                "name"=> "TeasyMobile",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "090146",
                "code"=> "090146",
                "name"=> "Trident Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090193",
                "code"=> "090193",
                "name"=> "Unical Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "032",
                "code"=> "000018",
                "name"=> "Union Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "033",
                "code"=> "000004",
                "name"=> "United Bank for Africa",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "215",
                "code"=> "000011",
                "name"=> "Unity Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090251",
                "code"=> "090251",
                "name"=> "UNN MFB",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090123",
                "code"=> "090123",
                "name"=> "Verite Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090110",
                "code"=> "090110",
                "name"=> "VFD MFB",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090150",
                "code"=> "090150",
                "name"=> "Virtue Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090139",
                "code"=> "090139",
                "name"=> "Visa Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "329",
                "code"=> "100023",
                "name"=> "Visual ICT",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "330",
                "code"=> "100012",
                "name"=> "VTNetworks",
                "category"=> "10"
            ],
            [
                "cbnBankCode"=> "035",
                "code"=> "000017",
                "name"=> "Wema Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "090120",
                "code"=> "090120",
                "name"=> "Wetland Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090124",
                "code"=> "090124",
                "name"=> "Xslnce Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "090142",
                "code"=> "090142",
                "name"=> "Yes Microfinance Bank",
                "category"=> "9"
            ],
            [
                "cbnBankCode"=> "057",
                "code"=> "000015",
                "name"=> "Zenith Bank",
                "category"=> "2"
            ],
            [
                "cbnBankCode"=> "331",
                "code"=> "100018",
                "name"=> "ZenithMobile",
                "category"=> "10"
            ]
        ];

        foreach($banks as $bank)
        {
            if(Bank::where('cbnBankCode', $bank['cbnBankCode'])->exists())
                continue;
            
            Bank::create($bank);
        }
    }
}